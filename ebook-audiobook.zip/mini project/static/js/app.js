// Book recommendation functionality
let loadedGenres = new Set();

function createBookCard(book) {
    return `
        <div class="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div class="flex justify-center mb-4">
                <img src="${book.thumbnail || '/static/img/placeholder.png'}" 
                     alt="${book.title}"
                     class="h-48 object-cover rounded">
            </div>
            <h2 class="text-xl font-bold mb-2 line-clamp-2">${book.title}</h2>
            <p class="text-gray-600 mb-2">By ${book.authors.join(', ')}</p>
            ${book.rating !== 'N/A' ? 
                `<div class="flex items-center mb-2">
                    ${createStarRating(book.rating)}
                    <span class="text-yellow-500 ml-1">${book.rating}/5</span>
                </div>` : ''
            }
            <p class="text-gray-700 text-sm line-clamp-3">${book.description}</p>
            ${createCategoryTags(book.categories)}
        </div>
    `;
}

function createStarRating(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];
    
    for (let i = 0; i < 5; i++) {
        if (i < fullStars) {
            stars.push('★');
        } else if (i === fullStars && hasHalfStar) {
            stars.push('⯨');
        } else {
            stars.push('☆');
        }
    }
    
    return `<span class="text-yellow-500">${stars.join('')}</span>`;
}

function createCategoryTags(categories) {
    if (!categories.length) return '';
    
    return `
        <div class="mt-4">
            ${categories.map(category => 
                `<span class="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mr-2 mb-2">
                    ${category}
                </span>`
            ).join('')}
        </div>
    `;
}

async function loadGenreBooks(genre) {
    const genreSection = document.getElementById(`genre-${genre}`) || createGenreSection(genre);
    const booksGrid = genreSection.querySelector('.grid');
    
    try {
        const response = await fetch(`/books/${genre}`);
        const books = await response.json();
        
        booksGrid.innerHTML = books.map(book => createBookCard(book)).join('');
        
        if (!document.getElementById(`genre-${genre}`)) {
            document.getElementById('selectedBooks').appendChild(genreSection);
        }
        
        loadedGenres.add(genre);
    } catch (error) {
        console.error('Error loading books:', error);
        genreSection.innerHTML = '<p class="text-red-500">Error loading books for this genre</p>';
    }
}

function createGenreSection(genre) {
    const genreSection = document.createElement('div');
    genreSection.id = `genre-${genre}`;
    genreSection.innerHTML = `
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-2xl font-bold capitalize">${genre} Books</h2>
            <button onclick="refreshGenre('${genre}')" class="text-blue-600 hover:text-blue-800">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd" />
                </svg>
            </button>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"></div>
    `;
    return genreSection;
}

async function refreshGenre(genre) {
    const genreSection = document.getElementById(`genre-${genre}`);
    if (genreSection) {
        const booksGrid = genreSection.querySelector('.grid');
        booksGrid.innerHTML = '<div class="col-span-full text-center">Loading new recommendations...</div>';
        await loadGenreBooks(genre);
    }
}

function updateLoadButtonState() {
    const loadButton = document.getElementById('loadBooks');
    const checkedGenres = document.querySelectorAll('.genre-checkbox:checked');
    loadButton.disabled = checkedGenres.length === 0;
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    const loadButton = document.getElementById('loadBooks');
    const checkboxes = document.querySelectorAll('.genre-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateLoadButtonState();
        });
    });

    loadButton.addEventListener('click', async () => {
        const selectedGenres = Array.from(document.querySelectorAll('.genre-checkbox:checked'))
            .map(checkbox => checkbox.value);

        loadButton.disabled = true;
        loadButton.textContent = 'Loading...';

        for (const genre of selectedGenres) {
            await loadGenreBooks(genre);
        }

        loadButton.textContent = 'Load Selected Books';
        updateLoadButtonState();
    });

    // Initialize button state
    updateLoadButtonState();
});