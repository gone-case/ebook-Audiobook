class Book:
    def __init__(self, volume_info):
        self.volume_info = volume_info

    @property
    def title(self):
        return self.volume_info.get('title', 'N/A')

    @property
    def authors(self):
        return self.volume_info.get('authors', ['Unknown'])

    @property
    def description(self):
        return self.volume_info.get('description', 'No description available')

    @property
    def thumbnail(self):
        return self.volume_info.get('imageLinks', {}).get('thumbnail', '')

    @property
    def categories(self):
        return self.volume_info.get('categories', [])

    @property
    def rating(self):
        return self.volume_info.get('averageRating', 'N/A')

    def to_dict(self):
        return {
            'title': self.title,
            'authors': self.authors,
            'description': self.description,
            'thumbnail': self.thumbnail,
            'categories': self.categories,
            'rating': self.rating
        }