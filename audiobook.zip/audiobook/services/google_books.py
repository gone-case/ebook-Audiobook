import requests
import random
from urllib.parse import quote
from models import Book

class GoogleBooksService:
    API_URL = "https://www.googleapis.com/books/v1/volumes"
    API_KEY = "AIzaSyClxUppot4neh1acodi3KgT344ZY5QWWVs" 
    GENRES = {
        'fiction': 'subject:fiction',
        'mystery': 'subject:mystery',
        'romance': 'subject:romance',
        'science': 'subject:science',
        'fantasy': 'subject:fantasy'
    }

    @staticmethod
    def get_popular_books(genre, max_results=4):
        if genre not in GoogleBooksService.GENRES:
            print(f"Invalid genre: {genre}")
            return []  # Return empty if the genre is invalid

        # Get a larger pool of books to randomly select from
        params = {
            'q': GoogleBooksService.GENRES[genre],  # Use the genre query
            'maxResults': 40,  # Request more books to get a variety
            'orderBy': 'relevance',
            'filter': 'ebooks',
            'startIndex': random.randint(0, 36),  # Ensure startIndex doesn't exceed maxResults (40)
            'key': GoogleBooksService.API_KEY  # API key for authentication
        }
        
        try:
            response = requests.get(GoogleBooksService.API_URL, params=params)
            response.raise_for_status()
            data = response.json()
            
            books = []
            if 'items' in data:
                # Randomly select books from the results
                items = data['items']
                random.shuffle(items)
                selected_items = items[:max_results]
                
                for item in selected_items:
                    book = Book(item.get('volumeInfo', {}))
                    books.append(book.to_dict())
                    
            return books
        except requests.RequestException as e:
            print(f"Error fetching books: {e}")
            return []