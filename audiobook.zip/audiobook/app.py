from bs4 import BeautifulSoup
import ebooklib
from flask import Flask, render_template, redirect, url_for, session, flash, request, send_from_directory, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os
from gtts import gTTS
import pdfplumber
from ebooklib import epub

from services.google_books import GoogleBooksService

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Configure upload folder and allowed extensions
UPLOAD_FOLDER = 'uploads'
AUDIO_FOLDER = 'audio'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['AUDIO_FOLDER'] = AUDIO_FOLDER

# Ensure the folders exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(AUDIO_FOLDER, exist_ok=True)

DATABASE = "replace with your database.db" 

def process_text_with_timing(text):
    # Base timing parameters
    base_time = 0.27  # Base duration for a short word
    extra_time_per_char = 0.14  # Additional time for long words
    threshold_length = 4  # Threshold for word length
    comma_delay = 0.3  # Delay for a comma
    period_delay = 0.7  # Longer delay for a period

    words = []
    current_time = 0.0

    # Split text into words
    for word in text.split():
        if word.endswith(".") or word.endswith("?") or word.endswith("!") or word == ".":
            # Longer delay for a period
            words.append({
                "text": word,
                "time": current_time,
                "is_punctuation": True
            })
            current_time += period_delay
        elif word.endswith(",") or word == ",":
            # Shorter delay for a comma
            words.append({
                "text": word,
                "time": current_time,
                "is_punctuation": True
            })
            current_time += comma_delay
        else:
            # Calculate word duration
            extra_time = max(len(word) - threshold_length, 0) * extra_time_per_char
            duration = base_time + extra_time

            words.append({
                "text": word,
                "time": current_time,
                "is_punctuation": False
            })
            current_time += duration

    return words

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ['pdf', 'txt', 'epub', 'jpg', 'jpeg', 'png']

def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS favorites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            audio_file TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()

        if user:
            if check_password_hash(user[2], password):
                session['username'] = username
                flash("Login successful!", "success")
                return redirect(url_for('welcome'))
            else:
                error = "Incorrect password, try again."
                flash(error, "danger")
        else:
            flash("Invalid username. Please try again.", "danger")

    return render_template('login.html', error=error)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        try:
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
            conn.commit()
            conn.close()
            flash("Signup successful! You can now log in.", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username already exists. Please choose a different one.", "danger")

    return render_template('signup.html')

@app.route('/welcome', methods=['GET', 'POST'])
def welcome():
    if 'username' in session:
        audio_file = None
        text_content = None
        timings = None
        
        if request.method == 'POST':
            file = request.files.get('file')
            if not file or file.filename == '':
                flash('No selected file or file missing.', 'danger')
                return redirect(request.url)

            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)

                try:
                    # Convert file to text
                    text_content = extract_text_from_file(file_path, filename)

                    if text_content.strip():
                        # Process text timing
                        timings = process_text_with_timing(text_content)
                        
                        # Convert text to speech
                        tts = gTTS(text=text_content, lang='en')
                        audio_filename = f"{os.path.splitext(filename)[0]}.mp3"
                        audio_filepath = os.path.join(app.config['AUDIO_FOLDER'], audio_filename)
                        tts.save(audio_filepath)

                        flash("File converted to audio successfully!", "success")
                        audio_file = url_for('download_file', filename=audio_filename)
                    else:
                        flash("No readable text found in the file.", "danger")
                except Exception as e:
                    flash(f"An error occurred during conversion: {str(e)}", "danger")
                    print(f"Error during conversion: {e}")

        # Fetch favorites from the database
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT audio_file FROM favorites WHERE user_id = (SELECT id FROM users WHERE username = ?)", (session['username'],))
        favorites = cursor.fetchall()
        conn.close()

        return render_template(
            'welcome.html',
            audio_file=audio_file,
            favorites=[favorite[0] for favorite in favorites],
            text_content=text_content,
            timings=timings
        )

    else:
        flash("You need to log in first.", "danger")
        return redirect(url_for('login'))

@app.route('/process-text', methods=['POST'])
def process_text():
    data = request.get_json()
    if not data or 'text' not in data:
        return jsonify({'error': 'No text provided'}), 400

    try:
        timings = process_text_with_timing(data['text'])
        return jsonify({
            'timings': timings
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for('login'))


@app.route('/remove_from_favorites/', methods=['POST'])
def remove_from_favorites():
    if 'username' not in session:
        flash("You need to log in first.", "danger")
        return jsonify({"message": "You are not logged in."}), 401

    audio_file = request.form.get('audio_file')  # Retrieve from POST data
    if not audio_file:
        return jsonify({"message": "Audio file not specified."}), 400

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Get the user's ID
    cursor.execute("SELECT id FROM users WHERE username = ?", (session['username'],))
    user = cursor.fetchone()
    if not user:
        conn.close()
        return jsonify({"message": "User not found."}), 404

    user_id = user[0]

    # Delete the audio file from the favorites table
    cursor.execute("DELETE FROM favorites WHERE user_id = ? AND audio_file = ?", (user_id, audio_file))
    conn.commit()
    conn.close()

    return jsonify({"message": f"'{audio_file}' removed from favorites."}), 200


@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['AUDIO_FOLDER'], filename)

@app.route('/add_to_favorites', methods=['POST'])
def add_to_favorites():
    if 'username' not in session:
        flash("You need to log in first.", "danger")
        return redirect(url_for('login'))

    audio_file = request.form['audio_file']
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("SELECT id FROM users WHERE username = ?", (session['username'],))
    user_id = cursor.fetchone()[0]

    cursor.execute("INSERT INTO favorites (user_id, audio_file) VALUES (?, ?)", (user_id, audio_file))
    conn.commit()
    conn.close()

    flash("Added to favorites successfully!", "success")
    return redirect(url_for('welcome'))

def extract_text_from_file(file_path, filename):
    text = ""

    if filename.endswith('.pdf'):
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text()
    elif filename.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
    elif filename.endswith('.epub'):
        # Extract text from EPUB file
        book = epub.read_epub(file_path)
        for item in book.get_items():
            if item.get_type() == ebooklib.ITEM_DOCUMENT:  # Correct usage of ITEM_DOCUMENT
                # Parse the HTML content using BeautifulSoup
                soup = BeautifulSoup(item.content, 'html.parser')
                # Extract text from the <body> tag
                body_content = soup.find('body')
                if body_content:
                    text += body_content.get_text(separator="\n").strip() + "\n"
    else:
        flash("Unsupported file type.", "danger")

    return text
@app.route('/recommendations')
def recommendations():
    return render_template('rec.html')

@app.route('/books/<genre>')
def get_books(genre):
    books = GoogleBooksService.get_popular_books(genre)
    return jsonify(books)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)